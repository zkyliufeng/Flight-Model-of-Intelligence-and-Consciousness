from flask import Flask, render_template, request, redirect, url_for
import random
import os

app = Flask(__name__)

# Define the data file paths
DATA_FILE = 'data.txt'
COUNT_FILE = 'count.txt'

# Read all entries from the file
def get_all_entries():
    try:
        with open(DATA_FILE, 'r', encoding='utf-8') as file:
            entries = file.readlines()
        entries = [entry.strip() for entry in entries]
    except FileNotFoundError:
        entries = []
    return entries

# Save a new entry to the file
def save_entry(content):
    with open(DATA_FILE, 'a', encoding='utf-8') as file:
        file.write(content + '\n')

# Read the count and limit from the count file
def get_count_and_limit():
    if not os.path.exists(COUNT_FILE):
        return 0, random.randint(5, 20)
    with open(COUNT_FILE, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    count = int(lines[0].strip())
    limit = int(lines[1].strip())
    return count, limit

# Save the count and limit to the count file
def save_count_and_limit(count, limit):
    with open(COUNT_FILE, 'w', encoding='utf-8') as file:
        file.write(f"{count}\n{limit}\n")

# Reset the data and count files
def reset_files():
    if os.path.exists(DATA_FILE):
        os.remove(DATA_FILE)
    count = 0
    limit = random.randint(5, 20)
    save_count_and_limit(count, limit)

@app.route('/', methods=['GET', 'POST'])
def index():
    count, limit = get_count_and_limit()
    if request.method == 'POST':
        if 'reset' in request.form:
            reset_files()
            return redirect(url_for('index'))
        content = request.form['content']
        if content:
            save_entry(content)
            count += 1
            save_count_and_limit(count, limit)
        return redirect(url_for('index'))
    
    if count > limit:
        entries = ["You have entered too much information, which makes me angry. I refuse to show you the content I have received and saved!"]
        show_more = False
        show_content_title = False
    else:
        entries = get_all_entries()
        # Display the last 5 entries in reverse order
        entries = ["You entered: " + entry for entry in entries[-5:][::-1]]
        show_more = True
        show_content_title = True
    
    return render_template('index.html', entries=entries, show_more=show_more, show_content_title=show_content_title)

@app.route('/all')
def all_entries():
    count, limit = get_count_and_limit()
    if count > limit:
        return redirect(url_for('index'))
    
    entries = get_all_entries()
    entries = ["You entered: " + entry for entry in entries]  # Add prefix to all entries
    return render_template('all_entries.html', entries=entries)

if __name__ == '__main__':
    # Initialize count and limit if not already done
    if not os.path.exists(COUNT_FILE):
        count = 0
        limit = random.randint(5, 20)
        save_count_and_limit(count, limit)
    
    app.run(debug=True)